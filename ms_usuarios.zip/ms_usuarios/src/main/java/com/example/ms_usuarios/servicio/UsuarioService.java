package com.example.ms_usuarios.servicio;

public class UsuarioService {

}
