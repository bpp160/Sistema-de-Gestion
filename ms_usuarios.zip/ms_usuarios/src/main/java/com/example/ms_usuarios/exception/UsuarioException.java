package com.example.ms_usuarios.exception;


public class UsuarioException {

}
