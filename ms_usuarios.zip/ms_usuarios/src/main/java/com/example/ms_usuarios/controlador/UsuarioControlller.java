package com.example.ms_usuarios.controlador;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/Usuario")
public class UsuarioControlller {

}
