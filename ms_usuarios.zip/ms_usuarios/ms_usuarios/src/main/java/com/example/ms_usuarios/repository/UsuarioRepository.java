package com.example.ms_usuarios.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.ms_usuarios.modelo.Usuario;


import java.util.Optional;




@Repository
public interface UsuarioRepository extends
JpaRepository<Usuario,Long> {
    Optional<Usuario> findByIdAuth(Long idAuth);

    java.util.List<Usuario> findByApellidoContaining(String parte);


}
