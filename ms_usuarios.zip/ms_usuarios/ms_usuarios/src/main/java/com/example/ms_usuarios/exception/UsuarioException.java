package com.example.ms_usuarios.exception;


public class UsuarioException extends RuntimeException {
public UsuarioException(Long id) {
    super("Usuario con ID " + id + " no encontrado en el directorio.");
}
}
