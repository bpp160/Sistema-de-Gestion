package com.example.ms_seguimiento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsSeguimientoApplicationTests {

	@Test
	void contextLoads() {
	}

}
