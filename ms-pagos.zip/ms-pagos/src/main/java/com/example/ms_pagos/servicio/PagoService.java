package com.example.ms_pagos.servicio;

import com.example.ms_pagos.model.Pago;
import com.example.ms_pagos.model.Pago.EstadoPago;
import com.example.ms_pagos.repository.PagoRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class PagoService {

    private final PagoRepository pagoRepository;

    public PagoService(PagoRepository pagoRepository) {
        this.pagoRepository = pagoRepository;
    }

    // Procesar pago
    public Pago procesarPago(Pago pago) {

        pago.setFechaPago(LocalDateTime.now());

        // Simulación de validación financiera
        if (pago.getMonto().doubleValue() > 0) {
            pago.setEstado(EstadoPago.APROBADO.name());
        } else {
            pago.setEstado(EstadoPago.RECHAZADO.name());
        }

        return pagoRepository.save(pago);
    }

    // Buscar por ID
    public Pago obtenerPorId(Long id) {
        return pagoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pago no encontrado"));
    }

    // Buscar por pedido
    public Pago obtenerPorPedido(Long idPedido) {
        return pagoRepository.findByIdPedido(idPedido)
                .orElseThrow(() -> new RuntimeException("Pago no encontrado"));
    }

    // Listar todos
    public List<Pago> listarPagos() {
        return pagoRepository.findAll();
    }

    // Filtrar por estado
    public List<Pago> listarPorEstado(String estado) {
        return pagoRepository.findByEstado(estado);
    }
}
