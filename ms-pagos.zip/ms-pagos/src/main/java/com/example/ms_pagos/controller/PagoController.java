package com.example.ms_pagos.controller;

import org.springframework.web.bind.annotation.*;

import com.example.ms_pagos.model.Pago;
import com.example.ms_pagos.servicio.PagoService;

import java.util.List;

@RestController
@RequestMapping("/api/pagos")
public class PagoController {

    private final PagoService pagoService;

    public PagoController(PagoService pagoService) {
        this.pagoService = pagoService;
    }

    @PostMapping
    public Pago procesar(@RequestBody Pago pago) {
        return pagoService.procesarPago(pago);
    }

    @GetMapping
    public List<Pago> listar() {
        return pagoService.listarPagos();
    }

    @GetMapping("/{id}")
    public Pago obtener(@PathVariable Long id) {
        return pagoService.obtenerPorId(id);
    }

    @GetMapping("/pedido/{idPedido}")
    public Pago obtenerPorPedido(@PathVariable Long idPedido) {
        return pagoService.obtenerPorPedido(idPedido);
    }

    @GetMapping("/estado/{estado}")
    public List<Pago> listarPorEstado(@PathVariable String estado) {
        return pagoService.listarPorEstado(estado);
    }

    public enum MetodoPago {
    TRANSFERENCIA,
    TARJETA,
    EFECTIVO
}
}
