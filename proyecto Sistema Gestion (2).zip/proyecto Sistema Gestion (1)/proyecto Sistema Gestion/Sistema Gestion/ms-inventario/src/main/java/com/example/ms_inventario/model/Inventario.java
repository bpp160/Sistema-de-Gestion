package com.example.ms_inventario.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "inventario")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Inventario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "id_propiedad", nullable = false, unique = true)
    @NotNull(message = "El id de la propiedad es obligatorio")
    private Long idPropiedad;

    @Column(nullable = false)
    private Integer stock;

    @Column(nullable = false)
    private String estado;

    @Version
    private Integer version;

    public enum EstadoInventario {
        DISPONIBLE,
        RESERVADO,
        VENDIDO,
        BLOQUEADO
    }
}