package com.example.ms_catalogo.controller;

import com.example.ms_catalogo.model.Catalogo;
import com.example.ms_catalogo.service.CatalogoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/catalogo")
public class CatalogoController {

    private final CatalogoService catalogoService;

    public CatalogoController(CatalogoService catalogoService) {
        this.catalogoService = catalogoService;
    }

    @PostMapping
    public Catalogo crear(@RequestBody Catalogo catalogo) {
        return catalogoService.crearPropiedad(catalogo);
    }

    @GetMapping
    public List<Catalogo> listar() {
        return catalogoService.listarPropiedades();
    }

    @GetMapping("/{id}")
    public Catalogo obtener(@PathVariable Long id) {
        return catalogoService.obtenerPorId(id);
    }

    @GetMapping("/tipo/{tipo}")
    public List<Catalogo> buscarPorTipo(@PathVariable String tipo) {
        return catalogoService.buscarPorTipo(tipo);
    }

    @GetMapping("/ubicacion/{ubicacion}")
    public List<Catalogo> buscarPorUbicacion(@PathVariable String ubicacion) {
        return catalogoService.buscarPorUbicacion(ubicacion);
    }

    @PutMapping("/{id}")
    public Catalogo actualizar(@PathVariable Long id,
            @RequestBody Catalogo catalogo) {
        return catalogoService.actualizarPropiedad(id, catalogo);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        catalogoService.eliminarPropiedad(id);
    }
}
