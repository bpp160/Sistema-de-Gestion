package com.example.ms_catalogo.exception;

public class CatalogoException extends RuntimeException {

    public CatalogoException(String mensaje) {
        super(mensaje);
    }
}