package com.example.ms_notificaciones.controller;

import com.example.ms_notificaciones.model.Notificacion;
import com.example.ms_notificaciones.service.NotificacionService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notificaciones")
public class NotificacionController {

    private final NotificacionService notificacionService;

    public NotificacionController(NotificacionService notificacionService) {
        this.notificacionService = notificacionService;
    }

    @PostMapping
    public Notificacion enviar(@RequestBody Notificacion notificacion) {
        return notificacionService.enviarNotificacion(notificacion);
    }

    @GetMapping
    public List<Notificacion> listar() {
        return notificacionService.listarNotificaciones();
    }

    @GetMapping("/destinatario/{email}")
    public List<Notificacion> porDestinatario(@PathVariable String email) {
        return notificacionService.obtenerPorDestinatario(email);
    }

    @GetMapping("/estado/{estado}")
    public List<Notificacion> porEstado(@PathVariable String estado) {
        return notificacionService.obtenerPorEstado(estado);
    }
}