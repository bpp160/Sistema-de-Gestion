package com.example.ms_reportes.service;

import com.example.ms_reportes.DTOs.PagoDTO;
import com.example.ms_reportes.DTOs.PedidoDTO;
import com.example.ms_reportes.client.PagoClient;
import com.example.ms_reportes.client.PedidoClient;
import com.example.ms_reportes.model.Reporte;
import com.example.ms_reportes.repository.ReporteRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class ReporteService {

    private final PedidoClient pedidoClient;
    private final PagoClient pagoClient;
    private final ReporteRepository reporteRepository;

    public ReporteService(PedidoClient pedidoClient,
            PagoClient pagoClient,
            ReporteRepository reporteRepository) {
        this.pedidoClient = pedidoClient;
        this.pagoClient = pagoClient;
        this.reporteRepository = reporteRepository;
    }

    // 🔥 Generar reporte completo
    public Reporte generarReporte() {

        List<PedidoDTO> pedidos = pedidoClient.obtenerPedidos();
        List<PagoDTO> pagos = pagoClient.obtenerPagos();

        BigDecimal totalVentas = pagos.stream()
                .filter(p -> p.getEstado().equals("APROBADO"))
                .map(PagoDTO::getMonto)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        int totalPedidos = pedidos.size();

        long pedidosCompletados = pedidos.stream()
                .filter(p -> p.getEstado().equals("COMPLETADO"))
                .count();

        Reporte reporte = new Reporte();
        reporte.setTotalVentas(totalVentas);
        reporte.setTotalPedidos(totalPedidos);
        reporte.setPedidosCompletados(pedidosCompletados);
        reporte.setFechaGeneracion(LocalDateTime.now());

        return reporteRepository.save(reporte);
    }

    // 📊 Listar reportes históricos
    public List<Reporte> listarReportes() {
        return reporteRepository.findAllByOrderByFechaGeneracionDesc();
    }

    // 🔍 Obtener por ID
    public Reporte obtenerReporte(Long id) {
        return reporteRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Reporte no encontrado"));
    }
}
