package com.example.ms_reportes.DTOs;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class PagoDTO {
    private Long id;
    private BigDecimal monto;
    private String estado;
}
