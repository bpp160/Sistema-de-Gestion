package com.example.ms_promociones.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "promociones")
@Data
public class Promocion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String codigo; // Ej: "VERANO2026"

    @Column(nullable = false)
    private int porcentajeDescuento; // Ej: 20 (para 20%)

    private boolean activa = true;
}
