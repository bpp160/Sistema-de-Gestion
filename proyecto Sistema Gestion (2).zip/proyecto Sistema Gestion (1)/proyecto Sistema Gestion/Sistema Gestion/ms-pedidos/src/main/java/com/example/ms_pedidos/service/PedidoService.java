package com.example.ms_pedidos.service;

import com.example.ms_pedidos.model.EstadoPedido;
import com.example.ms_pedidos.model.Pedido;
import com.example.ms_pedidos.repository.PedidoRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class PedidoService {

    private final PedidoRepository pedidoRepository;

    public PedidoService(PedidoRepository pedidoRepository) {
        this.pedidoRepository = pedidoRepository;
    }

    public Pedido crearPedido(Pedido pedido) {

        pedido.setEstado(EstadoPedido.CREADO.name());
        pedido.setFechaCreacion(LocalDateTime.now());

        return pedidoRepository.save(pedido);
    }

    public List<Pedido> listarPedidos() {
        return pedidoRepository.findAll();
    }

    public Pedido obtenerPorId(Long id) {
        return pedidoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));
    }

    public List<Pedido> obtenerPorUsuario(Long idUsuario) {
        return pedidoRepository.findByIdUsuario(idUsuario);
    }

    public Pedido cancelarPedido(Long id) {

        Pedido pedido = obtenerPorId(id);
        pedido.setEstado(EstadoPedido.CANCELADO.name());

        return pedidoRepository.save(pedido);
    }

    public Pedido completarPedido(Long id) {

        Pedido pedido = obtenerPorId(id);
        pedido.setEstado(EstadoPedido.COMPLETADO.name());

        return pedidoRepository.save(pedido);
    }
}
