package com.example.ms_usuarios.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.ms_usuarios.modelo.Usuario;
import com.example.ms_usuarios.service.UsuarioService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {
    @Autowired
    private UsuarioService service;

    // 1. CREAR USUARIO (Aquí actúa el @Valid para atrapar errores y mandarlos al ExceptionHandler)
    @PostMapping
    public ResponseEntity<?> crearUsuario(@Valid @RequestBody Usuario usuario){
        // Validación extra de negocio: no repetir correos
        if(service.existeCorreo(usuario.getEmail())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error: EL correo " + usuario.getEmail() + " ya esta registrado.");
        }

        Usuario nuevUsuario = service.guardarUsuario(usuario);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevUsuario);
    }

    // 2. BUSCAR POR ID INTERNO
    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id) {
        Usuario usuario = service.buscarPorId(id);
        if (usuario != null) {
            return ResponseEntity.ok(usuario);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body("Error : No se encontro el usuario con ID " + id);
    }

    // 3. BUSCAR POR ID DE SEGURIDAD (idAuth)
    @GetMapping("/auth/{idAuth}")
    public ResponseEntity<?> buscarPorIdAuth(@PathVariable Long idAuth) {
        Usuario usuario = service.buscarPorIdAuth(idAuth);
        if (usuario != null ) {
            return ResponseEntity.ok(usuario);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body("Error : No hay perfil asociado a la cuenta de seguridad " + idAuth);
    }

    // 4. LISTAR TODOS
    @GetMapping
    public ResponseEntity<List<Usuario>> listarTodos() {
        return ResponseEntity.ok(service.listarTodos());
    }

    // 5. BUSCADOR PARCIAL POR APELLIDO (Ej: /api/usuarios/buscar?apellido=Perez)
    @GetMapping("/buscar")
    public ResponseEntity<List<Usuario>> buscarPorApellido(@RequestParam String apellido) {
        return ResponseEntity.ok(service.buscarPorApellido(apellido));
    }
}


