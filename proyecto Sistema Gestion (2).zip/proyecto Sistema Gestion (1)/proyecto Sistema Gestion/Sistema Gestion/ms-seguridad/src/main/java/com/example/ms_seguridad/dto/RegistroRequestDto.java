package com.example.ms_seguridad.dto;

import lombok.Data;

@Data
public class RegistroRequestDto {
    // Datos para ms-seguridad
    private String email;
    private String password;
    private String rol;

    // Datos que enviaremos a ms-usuarios por Feign
    private String nombre;
    private String apellido;
    private String telefono;
}
